# OpenCV-Face-Recognition
Real-time face recognition project with OpenCV and Python
<br><br>
<p><img src="https://github.com/NoNum3"></p>
